const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
$('#th').onclick=()=>{const t=document.documentElement.dataset.theme==='dark'?'light':'dark';document.documentElement.dataset.theme=t;try{localStorage.t=t}catch(e){}};
$('#bg').onclick=()=>document.body.classList.toggle('open');
$$('#menu a').forEach(a=>a.onclick=()=>document.body.classList.remove('open'));
$$('.f').forEach(b=>b.onclick=()=>{$$('.f').forEach(x=>x.classList.toggle('on',x===b));$$('.card').forEach(c=>c.hidden=b.dataset.c!=='*'&&c.dataset.c!==b.dataset.c)});
$$('[data-d]').forEach(b=>b.onclick=()=>document.getElementById(b.dataset.d).showModal());
$$('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d||e.target.closest('.x'))d.close()}));
const tp=$('#tp');if(tp){const L=JSON.parse($('.term').dataset.lines),rm=matchMedia('(prefers-reduced-motion:reduce)').matches,w=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{for(const l of L){const d=document.createElement('div');tp.append(d);if(rm||l[0]!=='$'){d.textContent=l;await w(rm?0:250)}else{d.className='c';for(const c of l){d.textContent+=c;await w(40)}await w(200)}}})()}
