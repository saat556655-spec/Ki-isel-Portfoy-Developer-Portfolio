<?php
require __DIR__.'/lib.php';
if(is_file(__DIR__.'/config.php')){http_response_code(403);exit('Kurulum tamamlanmış. install.php dosyasını sunucudan silin.');}
$err='';
if($_SERVER['REQUEST_METHOD']==='POST'&&csrf_ok()){
 $lite=($_POST['drv']??'sqlite')==='sqlite';[$h,$pt]=array_pad(explode(':',trim($_POST['host']),2),2,'3306');
 $c=$lite?['driver'=>'sqlite','file'=>'']:['driver'=>'mysql','host'=>$h,'port'=>$pt,'name'=>trim($_POST['db']),'user'=>trim($_POST['du']),'pass'=>(string)$_POST['dp']];
 $au=trim($_POST['au']);$ap=(string)$_POST['ap'];$nm=trim($_POST['nm']);
 try{
  if($au===''||strlen($ap)<10)throw new Exception('Yönetici adı gerekli, şifre en az 10 karakter olmalı.');
  if(!$lite&&($c['name']===''||$c['user']===''))throw new Exception('MySQL için veritabanı adı ve kullanıcı gerekli.');
  $o=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION];
  if($lite){if(!extension_loaded('pdo_sqlite'))throw new Exception('Bu sunucuda SQLite yok, MySQL seçin.');$dir=is_writable(dirname(__DIR__))?dirname(__DIR__):__DIR__.'/data';$c['file']=$dir.'/portfolio-'.bin2hex(random_bytes(8)).'.sqlite';}
  $p=$lite?new PDO('sqlite:'.$c['file'],null,null,$o):new PDO("mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset=utf8mb4",$c['user'],$c['pass'],$o);
  $ai=$lite?'INTEGER PRIMARY KEY AUTOINCREMENT':'INT AUTO_INCREMENT PRIMARY KEY';
  foreach([
  'CREATE TABLE settings(k VARCHAR(40) PRIMARY KEY,v TEXT)',
  'CREATE TABLE projects(id '.$ai.',title VARCHAR(120),title_en VARCHAR(120),descr TEXT,descr_en TEXT,category VARCHAR(60),tech VARCHAR(255),github VARCHAR(255),demo VARCHAR(255))',
  'CREATE TABLE skills(id '.$ai.',cat VARCHAR(60),name VARCHAR(60))',
  'CREATE TABLE messages(id '.$ai.',name VARCHAR(100),email VARCHAR(150),subject VARCHAR(150),body TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)',
  'CREATE TABLE admins(id '.$ai.',username VARCHAR(60) UNIQUE,pass VARCHAR(255))'] as $q)$p->exec($q);
  $J=content();$J['settings']['name']=$nm;$J['settings']['mono']=mb_substr($nm,0,1).'.';$J['settings']['email']=trim($_POST['em']);$J['settings']['seo_title']=$nm.' — Yazılım Geliştirici';$J['settings']['seo_desc']=$nm.' kişisel yazılım geliştirici portföyü.';
  $st=$p->prepare('INSERT INTO settings(k,v) VALUES(?,?)');foreach($J['settings'] as $k=>$v)$st->execute([$k,$v]);
  $sk=$p->prepare('INSERT INTO skills(cat,name) VALUES(?,?)');foreach($J['skills'] as $cat=>$ns)foreach($ns as $n)$sk->execute([$cat,$n]);
  $pp=$p->prepare('INSERT INTO projects(title,title_en,descr,descr_en,category,tech,github,demo) VALUES(?,?,?,?,?,?,?,?)');foreach($J['projects'] as $r)$pp->execute([$r['title'],$r['title_en']??'',$r['descr'],$r['descr_en']??'',$r['category'],$r['tech']??'',$r['github']??'',$r['demo']??'']);
  $mf=__DIR__.'/data/messages.jsonl.php';if(is_file($mf)){$mp=$p->prepare('INSERT INTO messages(name,email,subject,body,created_at) VALUES(?,?,?,?,?)');foreach(array_slice(file($mf,FILE_IGNORE_NEW_LINES),1) as $ln){$j=json_decode($ln,true);if($j)$mp->execute([$j['n'],$j['m'],$j['s'],$j['b'],$j['t']]);}}
  $p->prepare('INSERT INTO admins(username,pass) VALUES(?,?)')->execute([$au,password_hash($ap,PASSWORD_DEFAULT)]);
  file_put_contents(__DIR__.'/config.php','<?php return '.var_export($c,true).';',LOCK_EX);@chmod(__DIR__.'/config.php',0640);
  header('Location: admin.php');exit;
 }catch(Throwable $x){$err=$x->getMessage();}
}
?><!doctype html><html lang="tr" data-theme="dark"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Kurulum</title><link rel="stylesheet" href="assets/style.css"></head><body>
<div class="adm"><h1>Kurulum</h1>
<?php if($err):?><p class="er"><?=e($err)?></p><?php endif?>
<form method="post" autocomplete="off"><?=field()?>
<h2>1. Site ve kişisel bilgi</h2><label>Ad Soyad<input name="nm" required></label><label>İletişim e-postası<input name="em" type="email" required></label>
<h2>2. Veritabanı</h2><label>Tür<select name="drv"><option value="sqlite">SQLite — ayar gerekmez (önerilen)</option><option value="mysql">MySQL</option></select></label><p class="mu">Aşağıdaki alanlar yalnızca MySQL için:</p><label>Sunucu (host veya host:port)<input name="host" value="localhost"></label><label>Veritabanı adı<input name="db"></label><label>Kullanıcı<input name="du"></label><label>Şifre<input name="dp" type="password"></label>
<h2>3. Yönetici hesabı</h2><label>Kullanıcı adı<input name="au" required></label><label>Şifre (en az 10 karakter)<input name="ap" type="password" minlength="10" required></label>
<button class="btn pri">Kurulumu tamamla</button></form></div></body></html>
