# Kişisel Geliştirici Portföyü

PHP 8.2+ ile yazılmış, bağımlılıksız (Composer/npm yok) kişisel portföy sitesi. Kurulum sihirbazı, yönetim paneli ve TR/EN içerik desteği içerir. Veritabanı olmadan da `data/content.json` üzerinden çalışır.

> **Durum:** Kod PHP çalıştırılabilen bir ortamda test edilmedi. İlk kurulumda hata görürseniz hata mesajını not edin.

## Özellikler

- Koyu/açık tema, TR/EN dil geçişi, mobil hamburger menü
- Hero bölümünde terminal animasyonu (yetenek listesinden beslenir)
- Yetenekler, filtrelenebilir proje galerisi ve detay penceresi, çalışma süreci
- İletişim formu: CSRF, honeypot, gönderim süresi kontrolü, doğrulama
- Yönetim paneli: projeler (ekle/düzenle/sil), yetenekler (ekle/sil), site ayarları (TR/EN metinler, bağlantılar, SEO başlık ve açıklama), gelen mesajlar
- Üç çalışma modu: JSON (veritabanı yok), SQLite, MySQL

## Gereksinimler

- PHP 8.2 veya üstü, `mbstring` ve `PDO` (`pdo_sqlite` veya `pdo_mysql`)
- `data/` klasörüne ve web kökünün bir üst klasörüne (veya `data/`) yazma izni

## Dosya yapısı

```
index.php        Ana sayfa ve iletişim formu
install.php      Kurulum sihirbazı (kurulumdan sonra silin)
admin.php        Yönetim paneli
lib.php          Oturum, CSRF, veritabanı bağlantısı, JSON yedek katmanı
assets/          style.css, app.js
data/content.json        Başlangıç içeriği ve JSON modu verisi
data/messages.jsonl.php  JSON modunda gelen mesajlar (otomatik oluşur)
config.php       Kurulumda otomatik oluşur
.htaccess        Yalnızca Apache için (nginx okumaz)
```

## Kurulum

1. `portfolio.zip` içeriğini web köküne açın. Dosyalar alt klasörde değil, doğrudan kökte olmalı (Pterodactyl nginx egg'inde `/home/container/www`).
2. `https://siteadresi/install.php` sayfasını açın.
3. Veritabanı türünü seçin:
   - **SQLite (önerilen):** Ayar gerekmez. Dosya, web kökünün üst klasörüne yazılabiliyorsa oraya, değilse `data/` içine rastgele adla oluşturulur.
   - **MySQL:** Sunucu, veritabanı adı, kullanıcı ve şifre girin. Sunucu alanına `host` veya `host:port` yazılabilir. `localhost` konteyner/ayrı sunucu kurulumlarında çalışmayabilir.
4. Yönetici kullanıcı adını ve en az 10 karakterlik şifreyi girip kurulumu tamamlayın.
5. `install.php` dosyasını sunucudan silin.

Yönetim paneli: `https://siteadresi/admin.php`

Yeniden kurulum gerekirse `config.php` dosyasını silin. MySQL kullanıyorsanız önce tabloları da silin.

## JSON modu

`config.php` yoksa veya veritabanına bağlanılamıyorsa site içeriği `data/content.json` dosyasından okur.

- `settings`: isim, monogram, hero ve hakkımda metinleri (`_tr` / `_en`), e-posta, GitHub, Discord, SEO
- `skills`: kategori adı ve yetenek listesi
- `projects`: her proje için benzersiz `id`, `title`, `title_en`, `descr`, `descr_en`, `category`, `tech`, `github`, `demo`

Bu modda iletişim formu mesajları `data/messages.jsonl.php` dosyasına yazılır. Kurulum sırasında `content.json` ve biriken mesajlar veritabanına aktarılır. Admin paneli yalnızca kurulumdan sonra çalışır.

## Güvenlik

- Şifreler `password_hash` ile saklanır
- Tüm sorgular PDO hazır ifadeleriyle çalışır, tüm çıktılar escape edilir
- Her POST formunda CSRF belirteci vardır
- Oturum çerezi `HttpOnly` ve `SameSite=Strict`, girişte oturum kimliği yenilenir
- Proje ve sosyal bağlantılar yalnızca `http(s)` kabul eder
- `config.php` çalıştırıldığında çıktı üretmez, mesaj dosyası PHP koruma satırıyla başlar
- Admin sayfası `noindex` gönderir

Bilinen sınırlar: giriş denemesi sınırı yok (yalnızca 0,5 sn gecikme), admin'de şifre değiştirme yok, iletişim mesajları için e-posta bildirimi yok. `.htaccess` nginx'te çalışmaz. SQLite dosyası `data/` içine düştüyse rastgele adına güvenilir, mümkünse üst klasörün yazılabilir olduğundan emin olun.

## Henüz yok

GitHub API entegrasyonu, profil fotoğrafı/logo/favicon yükleme, proje görselleri, yetenek ikonları, yükleme ekranı, özel imleç, sitemap.xml, robots.txt, Schema.org, admin'de yetenek düzenleme ve tema ayarları.

## Tasarım

Arka plan `#0B0C0E`, ikincil `#111317`, metin `#F3F3F0`, vurgu `#B8F36B`. Yazı tipleri Inter ve Space Grotesk (Google Fonts'tan yüklenir). Renkler `assets/style.css` başındaki değişkenlerden değiştirilir.
