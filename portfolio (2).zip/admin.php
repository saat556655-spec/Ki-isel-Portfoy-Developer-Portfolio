<?php
require __DIR__.'/lib.php';
if(!cfg()){header('Location: install.php');exit;}
header('X-Robots-Tag: noindex');
const SET=['name'=>'Ad Soyad','mono'=>'Monogram','h1_tr'=>'Başlık (TR)','h1_en'=>'Başlık (EN)','sub_tr'=>'Alt açıklama (TR)','sub_en'=>'Alt açıklama (EN)','about_tr'=>'Hakkımda (TR)','about_en'=>'Hakkımda (EN)','email'=>'E-posta','github'=>'GitHub URL','discord'=>'Discord URL','seo_title'=>'SEO başlık','seo_desc'=>'SEO açıklama'];
$db=db();$msg='';$in=!empty($_SESSION['adm']);
$url=fn($u)=>preg_match('~^https?://~i',trim((string)$u))?trim($u):'';
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!csrf_ok()){http_response_code(400);exit('CSRF');}
 $a=$_POST['a']??'';$id=(int)($_POST['id']??0);
 if($a==='login'){usleep(500000);$q=$db->prepare('SELECT * FROM admins WHERE username=?');$q->execute([$_POST['u']??'']);$r=$q->fetch();
  if($r&&password_verify((string)($_POST['p']??''),$r['pass'])){session_regenerate_id(true);$_SESSION['adm']=$r['id'];header('Location: admin.php');exit;}$msg='Hatalı giriş.';}
 elseif(!$in){http_response_code(403);exit;}
 elseif($a==='logout'){$_SESSION=[];session_destroy();header('Location: admin.php');exit;}
 elseif($a==='set'){$q=$db->prepare('REPLACE INTO settings(k,v) VALUES(?,?)');foreach(SET as $k=>$_)$q->execute([$k,$k==='github'||$k==='discord'?$url($_POST[$k]??''):trim((string)($_POST[$k]??''))]);$msg='Kaydedildi.';}
 elseif($a==='proj'){$v=[];foreach(['title','title_en','descr','descr_en','category','tech'] as $k)$v[]=trim((string)($_POST[$k]??''));$v[]=$url($_POST['github']??'');$v[]=$url($_POST['demo']??'');
  if($id){$v[]=$id;$db->prepare('UPDATE projects SET title=?,title_en=?,descr=?,descr_en=?,category=?,tech=?,github=?,demo=? WHERE id=?')->execute($v);}
  else $db->prepare('INSERT INTO projects(title,title_en,descr,descr_en,category,tech,github,demo) VALUES(?,?,?,?,?,?,?,?)')->execute($v);$msg='Kaydedildi.';}
 elseif($a==='pdel')$db->prepare('DELETE FROM projects WHERE id=?')->execute([$id]);
 elseif($a==='sadd')$db->prepare('INSERT INTO skills(cat,name) VALUES(?,?)')->execute([trim((string)$_POST['cat']),trim((string)$_POST['name'])]);
 elseif($a==='sdel')$db->prepare('DELETE FROM skills WHERE id=?')->execute([$id]);
 elseif($a==='mdel')$db->prepare('DELETE FROM messages WHERE id=?')->execute([$id]);
}
function del($a,$id){return '<form method="post" class="inl">'.field().'<input type="hidden" name="a" value="'.$a.'"><input type="hidden" name="id" value="'.(int)$id.'"><button class="btn sm">Sil</button></form>';}
$pg=$_GET['p']??'dash';
?><!doctype html><html lang="tr" data-theme="dark"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Yönetim</title><link rel="stylesheet" href="assets/style.css"></head><body><div class="adm">
<?php if(!$in):?><h1>Giriş</h1><?php if($msg):?><p class="er"><?=e($msg)?></p><?php endif?><form method="post"><?=field()?><input type="hidden" name="a" value="login"><label>Kullanıcı adı<input name="u" required></label><label>Şifre<input name="p" type="password" required></label><button class="btn pri">Giriş yap</button></form>
<?php else:?>
<nav class="an"><?php foreach(['dash'=>'Panel','projects'=>'Projeler','skills'=>'Yetenekler','settings'=>'Ayarlar','messages'=>'Mesajlar'] as $k=>$l):?><a href="?p=<?=$k?>"<?=$pg===$k?' class="cur"':''?>><?=$l?></a><?php endforeach?><a href="./" target="_blank">Siteyi aç</a><form method="post" class="inl"><?=field()?><input type="hidden" name="a" value="logout"><button>Çıkış</button></form></nav>
<?php if($msg):?><p class="okm"><?=e($msg)?></p><?php endif?>
<?php if($pg==='dash'):foreach(['projects'=>'Proje','skills'=>'Yetenek','messages'=>'Mesaj'] as $t=>$l):?><p class="stat"><b><?=$db->query("SELECT COUNT(*) FROM $t")->fetchColumn()?></b> <?=$l?></p><?php endforeach?>
<?php elseif($pg==='projects'):$ed=['id'=>0,'title'=>'','title_en'=>'','descr'=>'','descr_en'=>'','category'=>'','tech'=>'','github'=>'','demo'=>''];
 if(!empty($_GET['edit'])){$q=$db->prepare('SELECT * FROM projects WHERE id=?');$q->execute([(int)$_GET['edit']]);$ed=$q->fetch()?:$ed;}
 foreach($db->query('SELECT id,title,category FROM projects ORDER BY id DESC') as $r):?><div class="it"><span><?=e($r['title'])?> <small class="mu"><?=e($r['category'])?></small></span><span><a class="btn sm" href="?p=projects&edit=<?=$r['id']?>">Düzenle</a> <?=del('pdel',$r['id'])?></span></div><?php endforeach?>
<h2><?=$ed['id']?'Projeyi düzenle':'Proje ekle'?></h2><form method="post"><?=field()?><input type="hidden" name="a" value="proj"><input type="hidden" name="id" value="<?=$ed['id']?>">
<?php foreach(['title'=>'Ad (TR)','title_en'=>'Ad (EN)','category'=>'Kategori','tech'=>'Teknolojiler (virgülle)','github'=>'GitHub URL','demo'=>'Demo URL'] as $k=>$l):?><label><?=$l?><input name="<?=$k?>" value="<?=e($ed[$k])?>"<?=$k==='title'||$k==='category'?' required':''?>></label><?php endforeach?>
<label>Açıklama (TR)<textarea name="descr" rows="4"><?=e($ed['descr'])?></textarea></label><label>Açıklama (EN)<textarea name="descr_en" rows="4"><?=e($ed['descr_en'])?></textarea></label><button class="btn pri">Kaydet</button></form>
<?php elseif($pg==='skills'):foreach($db->query('SELECT * FROM skills ORDER BY cat,id') as $r):?><div class="it"><span><?=e($r['name'])?> <small class="mu"><?=e($r['cat'])?></small></span><?=del('sdel',$r['id'])?></div><?php endforeach?>
<h2>Yetenek ekle</h2><form method="post"><?=field()?><input type="hidden" name="a" value="sadd"><label>Kategori<input name="cat" required></label><label>Ad<input name="name" required></label><button class="btn pri">Ekle</button></form>
<?php elseif($pg==='settings'):$s=settings();?><form method="post"><?=field()?><input type="hidden" name="a" value="set"><?php foreach(SET as $k=>$l):?><label><?=$l?><?php if(str_contains($k,'about')||str_contains($k,'sub')||$k==='seo_desc'):?><textarea name="<?=$k?>" rows="3"><?=e($s[$k]??'')?></textarea><?php else:?><input name="<?=$k?>" value="<?=e($s[$k]??'')?>"><?php endif?></label><?php endforeach?><button class="btn pri">Kaydet</button></form>
<?php else:foreach($db->query('SELECT * FROM messages ORDER BY id DESC') as $r):?><div class="it"><span><b><?=e($r['name'])?></b> &lt;<?=e($r['email'])?>&gt; <small class="mu"><?=e($r['created_at'])?></small><br><b><?=e($r['subject'])?></b><br><?=nl2br(e($r['body']))?></span><?=del('mdel',$r['id'])?></div><?php endforeach?>
<?php endif;endif?></div></body></html>
