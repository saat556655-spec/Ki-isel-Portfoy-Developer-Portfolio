<?php
declare(strict_types=1);
session_set_cookie_params(['httponly'=>true,'samesite'=>'Strict','secure'=>!empty($_SERVER['HTTPS'])]);
session_start();
function e($s):string{return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function cfg(){static $c;return $c??=(is_file(__DIR__.'/config.php')?require __DIR__.'/config.php':null);}
function db():PDO{static $p;if(!$p){$c=cfg();$o=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];$p=($c['driver']??'mysql')==='sqlite'?new PDO('sqlite:'.$c['file'],null,null,$o):new PDO("mysql:host={$c['host']};port=".($c['port']??3306).";dbname={$c['name']};charset=utf8mb4",$c['user'],$c['pass'],$o);}return $p;}
function csrf():string{return $_SESSION['t']??=bin2hex(random_bytes(32));}
function csrf_ok():bool{return hash_equals($_SESSION['t']??'',(string)($_POST['t']??''));}
function field():string{return '<input type="hidden" name="t" value="'.csrf().'">';}
function settings():array{static $s;return $s??=array_column(db()->query('SELECT k,v FROM settings')->fetchAll(),'v','k');}
function lang():string{if(in_array($_GET['lang']??'',['tr','en'],true)){setcookie('lang',$_GET['lang'],time()+31536000,'/');return $_GET['lang'];}return ($_COOKIE['lang']??'tr')==='en'?'en':'tr';}
function content():array{static $c;return $c??=(json_decode((string)@file_get_contents(__DIR__.'/data/content.json'),true)?:['settings'=>[],'skills'=>[],'projects'=>[]]);}
function site_data():array{
 static $d;if($d)return $d;
 try{if(cfg()){$db=db();$sk=[];foreach($db->query('SELECT * FROM skills ORDER BY id') as $r)$sk[$r['cat']][]=$r['name'];
  return $d=['src'=>'db','s'=>settings(),'sk'=>$sk,'pj'=>$db->query('SELECT * FROM projects ORDER BY id DESC')->fetchAll()];}}catch(Throwable $e){}
 $c=content();$def=['title_en'=>'','descr_en'=>'','tech'=>'','github'=>'','demo'=>''];
 $pj=array_map(fn($p)=>$p+$def,$c['projects']);usort($pj,fn($a,$b)=>$b['id']<=>$a['id']);
 return $d=['src'=>'json','s'=>$c['settings'],'sk'=>$c['skills'],'pj'=>$pj];}
function save_message(string $n,string $m,string $s,string $b):void{
 try{if(cfg()){db()->prepare('INSERT INTO messages(name,email,subject,body) VALUES(?,?,?,?)')->execute([$n,$m,$s,$b]);return;}}catch(Throwable $e){}
 $f=__DIR__.'/data/messages.jsonl.php';if(!is_file($f))file_put_contents($f,"<?php http_response_code(403);exit; ?>\n");
 if(filesize($f)>524288)return;
 file_put_contents($f,json_encode(['n'=>$n,'m'=>$m,'s'=>$s,'b'=>$b,'t'=>date('Y-m-d H:i:s')],JSON_UNESCAPED_UNICODE)."\n",FILE_APPEND|LOCK_EX);}
