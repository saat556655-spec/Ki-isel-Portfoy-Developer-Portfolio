<?php
require __DIR__.'/lib.php';
$L=lang();$D=site_data();$s=$D['s'];
if($_SERVER['REQUEST_METHOD']==='POST'){
 $n=trim($_POST['n']??'');$m=trim($_POST['m']??'');$sb=trim($_POST['s']??'');$b=trim($_POST['b']??'');
 $ok=csrf_ok()&&($_POST['website']??'')===''&&time()-($_SESSION['ft']??time())>=3&&$n!==''&&mb_strlen($n)<=100&&filter_var($m,FILTER_VALIDATE_EMAIL)&&mb_strlen($sb)<=150&&mb_strlen($b)>=10&&mb_strlen($b)<=3000;
 if($ok)save_message($n,$m,$sb,$b);
 $_SESSION['fl']=$ok?'ok':'err';header('Location: ./#contact');exit;
}
$_SESSION['ft']=time();$fl=$_SESSION['fl']??'';unset($_SESSION['fl']);
$T=['tr'=>['nav'=>['Ana Sayfa','Hakkımda','Yetenekler','Projeler','İletişim'],'eb'=>'INDEPENDENT DEVELOPER / AVAILABLE FOR PROJECTS','b1'=>'Projelerimi İncele','b2'=>'Benimle İletişime Geç','ab'=>'Biraz Ben.','pr'=>['Performans','Güvenlik','Kullanıcı deneyimi','Sürdürülebilir kod'],'all'=>'Tümü','more'=>'Detayları incele','proc'=>'Çalışma Süreci','n'=>'Ad Soyad','m'=>'E-posta','s'=>'Konu','b'=>'Mesaj','send'=>'Mesajı gönder','ok'=>'Mesajın iletildi, teşekkürler.','err'=>'Mesaj gönderilemedi. Alanları kontrol edip tekrar dene.','demo'=>'Canlı demo','close'=>'Kapat','st'=>['İhtiyacı ve hedefi netleştiririm.','Kapsamı, mimariyi ve takvimi çıkarırım.','Kodu küçük, test edilebilir parçalarla yazarım.','Hataları ve uç durumları yayından önce yakalarım.','Yayına alır, sonrasında da izlerim.'],'avail'=>'müsait'],
'en'=>['nav'=>['Home','About','Skills','Projects','Contact'],'eb'=>'INDEPENDENT DEVELOPER / AVAILABLE FOR PROJECTS','b1'=>'View my projects','b2'=>'Get in touch','ab'=>'A bit about me.','pr'=>['Performance','Security','User experience','Maintainable code'],'all'=>'All','more'=>'View details','proc'=>'How I work','n'=>'Full name','m'=>'Email','s'=>'Subject','b'=>'Message','send'=>'Send message','ok'=>'Message sent, thank you.','err'=>'Message not sent. Check the fields and try again.','demo'=>'Live demo','close'=>'Close','st'=>['I clarify the need and the goal.','I define scope, architecture and timeline.','I write code in small, testable pieces.','I catch bugs and edge cases before launch.','I ship it and keep watching it.'],'avail'=>'available']][$L];
$sk=$D['sk'];$pj=$D['pj'];$cats=array_values(array_unique(array_column($pj,'category')));
$tx=fn($r,$f)=>($L==='en'&&trim((string)$r[$f.'_en'])!=='')?$r[$f.'_en']:$r[$f];
$names=array_merge(...array_values($sk?:[[]]));
$lines=['$ whoami',$s['name'],'$ ls skills/',implode('  ',array_slice($names,0,5)),'$ status','● '.$T['avail']];
$ttl=$s['seo_title']??$s['name'];$sd=$s['seo_desc']??'';
?><!doctype html><html lang="<?=$L?>" data-theme="dark"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($ttl)?></title><meta name="description" content="<?=e($sd)?>"><meta property="og:title" content="<?=e($ttl)?>"><meta property="og:description" content="<?=e($sd)?>"><meta property="og:type" content="website">
<script>try{document.documentElement.dataset.theme=localStorage.t||'dark'}catch(e){}</script>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Space+Grotesk:wght@500;600&display=swap" rel="stylesheet"><link rel="stylesheet" href="assets/style.css"></head><body>
<header><a class="logo" href="#top"><?=e($s['mono']??'')?></a>
<nav id="menu"><?php foreach(['top','about','skills','projects','contact'] as $i=>$id):?><a href="#<?=$id?>"><?=$T['nav'][$i]?></a><?php endforeach?></nav>
<div class="tools"><a class="mono" href="?lang=<?=$L==='tr'?'en':'tr'?>"><?=$L==='tr'?'EN':'TR'?></a><button id="th" aria-label="Theme">◐</button><a class="btn sm" href="#contact"><?=$T['nav'][4]?></a><button id="bg" aria-label="Menu">≡</button></div></header>
<main>
<section id="top" class="hero"><div><p class="mono"><?=$T['eb']?></p><h1><?=e($s['h1_'.$L]??'')?></h1><p class="lead"><?=e($s['sub_'.$L]??'')?></p><div class="row"><a class="btn pri" href="#projects"><?=$T['b1']?></a><a class="btn" href="#contact"><?=$T['b2']?></a></div></div>
<div class="term" data-lines="<?=e(json_encode($lines))?>"><div class="bar"><i></i><i></i><i></i><span class="mono">~/<?=e(strtolower(str_replace(' ','-',$s['name']??'dev')))?></span></div><pre id="tp" aria-hidden="true"></pre></div></section>
<section id="about" class="two"><div><h2><?=$T['ab']?></h2></div><div><p class="lead"><?=e($s['about_'.$L]??'')?></p><ul class="pl"><?php foreach($T['pr'] as $x):?><li><?=$x?></li><?php endforeach?></ul></div></section>
<section id="skills"><h2><?=$T['nav'][2]?></h2><?php foreach($sk as $c=>$ns):?><div class="sk"><h3 class="mono"><?=e($c)?></h3><ul><?php foreach($ns as $n):?><li><?=e($n)?></li><?php endforeach?></ul></div><?php endforeach?></section>
<section id="projects"><h2><?=$T['nav'][3]?></h2>
<div class="fl"><button class="f on" data-c="*"><?=$T['all']?></button><?php foreach($cats as $c):?><button class="f" data-c="<?=e($c)?>"><?=e($c)?></button><?php endforeach?></div>
<div class="grid"><?php foreach($pj as $i=>$r):?><article class="card" data-c="<?=e($r['category'])?>"><span class="num"><?=str_pad((string)(count($pj)-$i),2,'0',STR_PAD_LEFT)?></span><p class="mono"><?=e($r['category'])?></p><h3><?=e($tx($r,'title'))?></h3><p class="cl"><?=e($tx($r,'descr'))?></p><p class="tech"><?=e($r['tech'])?></p><button class="btn sm" data-d="p<?=$r['id']?>"><?=$T['more']?></button></article>
<dialog id="p<?=$r['id']?>"><button class="x mono"><?=$T['close']?></button><p class="mono"><?=e($r['category'])?></p><h3><?=e($tx($r,'title'))?></h3><p><?=nl2br(e($tx($r,'descr')))?></p><p class="tech"><?=e($r['tech'])?></p><div class="row"><?php if($r['github']):?><a class="btn sm" rel="noopener" target="_blank" href="<?=e($r['github'])?>">GitHub</a><?php endif?><?php if($r['demo']):?><a class="btn sm" rel="noopener" target="_blank" href="<?=e($r['demo'])?>"><?=$T['demo']?></a><?php endif?></div></dialog><?php endforeach?></div></section>
<section id="process"><h2><?=$T['proc']?></h2><ol class="steps"><?php foreach(['Discover','Plan','Develop','Test','Launch'] as $i=>$n):?><li><span class="mono">0<?=$i+1?></span><h3><?=$n?></h3><p><?=$T['st'][$i]?></p></li><?php endforeach?></ol></section>
<section id="contact" class="two"><div><h2><?=$T['nav'][4]?></h2><p class="links"><?php if(!empty($s['email'])):?><a href="mailto:<?=e($s['email'])?>"><?=e($s['email'])?></a><?php endif?><?php if(!empty($s['github'])):?><a rel="noopener" target="_blank" href="<?=e($s['github'])?>">GitHub</a><?php endif?><?php if(!empty($s['discord'])):?><a rel="noopener" target="_blank" href="<?=e($s['discord'])?>">Discord</a><?php endif?></p></div>
<form method="post"><?=field()?><?php if($fl):?><p class="<?=$fl==='ok'?'okm':'er'?>" role="status"><?=$T[$fl]?></p><?php endif?><input class="hp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">
<label><?=$T['n']?><input name="n" required maxlength="100"></label><label><?=$T['m']?><input name="m" type="email" required></label><label><?=$T['s']?><input name="s" maxlength="150"></label><label><?=$T['b']?><textarea name="b" rows="5" required minlength="10" maxlength="3000"></textarea></label><button class="btn pri"><?=$T['send']?></button></form></section>
</main>
<footer><a class="logo" href="#top"><?=e($s['mono']??'')?></a><nav><?php foreach(['top','about','skills','projects','contact'] as $i=>$id):?><a href="#<?=$id?>"><?=$T['nav'][$i]?></a><?php endforeach?></nav><p class="mu">Designed with intention. Built with passion. © <?=date('Y')?> <?=e($s['name']??'')?></p><a href="#top" class="mono">↑</a></footer>
<script src="assets/app.js" defer></script></body></html>
